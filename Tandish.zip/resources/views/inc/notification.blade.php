<nav class="cd-nav-container" id="cd-nav">
	<header>
		<a href="#0" class="cd-close-nav">Close</a>
	</header>

	<ul class="cd-nav">

	</ul> <!-- .cd-3d-nav -->
</nav>
<div class="cd-overlay"><!-- shadow layer visible when navigation is visible --></div>