<div class="popular">
  <button id="open-button" class="btn btn--popular" title="{{ Auth::user()->name }}"><i class="las la-user"></i></button>
</div>
<div class="notification">
  <button title="Notification" class="btn btn--notification c-button"><i class="las la-bell"></i></button>
</div>
<!--<div class="popular">
  <button title="Popular"  id="c-button--push-right" class="btn btn--popular c-button"><i class="las la-fire-alt"></i></button>
</div>-->
<div class="search-wrap">
  <button title="Search" id="btn-search" class="btn btn--filter btn--search"><i class="las la-search"></i></button>
</div>  