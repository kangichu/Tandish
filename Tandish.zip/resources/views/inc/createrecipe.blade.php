<a href="/home" title="Home"><img class="logo" src="{{ asset('logo.svg') }}"></a>
<span class="create_recipe" title="New Recipe"><a href="/recipe"><i class="las la-plus-square"></i></a></span>
