<div class="modal fade bookmark" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-sm">
    <?php echo Form::open(['action' => ['BookmarksController@store', $post->id], 'method' => 'POST', 'class' => 'float-right']); ?>

      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="exampleModalLabel">Create Bookmark</h5>
        </div>
        <div class="modal-body">
          <?php echo e(Form::text('name', '', ['class' => 'form-control clean-slide', 'placeholder' => 'Enter Name Here'])); ?>

        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-primary" data-dismiss="modal" style="padding-right: 2em">Close</button>
          <?php echo e(Form::submit('Create', ['class'=>'btn submit'])); ?>

        </div>
      </div>
    <?php echo Form::close(); ?>

  </div>
</div><?php /**PATH C:\Users\user\Documents\reparie\resources\views/inc/bookmodal.blade.php ENDPATH**/ ?>