<div class="modal fade <?php echo e($post->id); ?>_modal" tabindex="-1" role="dialog" aria-labelledby="mySmallModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-sm">
    <?php echo Form::open(['action' => ['PostsController@destroy', $post->id], 'method' => 'POST', 'class' => 'float-right']); ?>

    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Remove Recipe</h5>
      </div>
      <div class="modal-body">
        Are you sure you want to continue with this action? Once done your recipe will be permanently deleted.
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-primary" data-dismiss="modal" style="padding-right: 2em">Close</button>
        <?php echo e(Form::hidden('_method', 'DELETE')); ?>

        <?php echo e(Form::submit('Delete', ['class' => 'btn submit'])); ?>

      </div>
    </div>
    <?php echo Form::close(); ?>

  </div>
</div><?php /**PATH C:\Users\user\Documents\reparie\resources\views/inc/recipesmodal.blade.php ENDPATH**/ ?>