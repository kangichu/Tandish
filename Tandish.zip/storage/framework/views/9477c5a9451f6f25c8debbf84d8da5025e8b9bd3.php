

<?php $__env->startSection('content'); ?>

    <main role="main" id="o-wrapper"  class="o-wrapper main-wrap">

     <!-- Navigation -->
      <div class="menu_nav">
        <?php echo $__env->make('inc.nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
      </div>

       <?php echo $__env->make('inc.createrecipe', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
       <?php echo $__env->make('inc.cookmodal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

      <div class="basic-info">
        <span>Recipes: <p><?php echo e($postCount); ?></p></span>
      </div>
      
      <!-- /Navigation -->

      <!-- COIDEA:demo START -->
      <div class="carousel">

        <span class="header">
          <p style="width: 16em"><?php echo e($cookbook->title); ?></p>
        </span>

        <?php if(!Auth::guest()): ?>
          <?php if(Auth::user()->id != $cookbook->user_id): ?>
             <span class="velo-slider__hint"><span><span>Cookbook</span></span></span>
          <?php else: ?>
            <span class="velo-slider__hint"><span><span>My Cookbook</span></span></span>
          <?php endif; ?>
        <?php endif; ?>

        <div class="social">
          <p><a href="/p/<?php echo e($cookbook->user->id); ?>" style="text-decoration: none; color: #fff"><?php echo e($cookbook->user->name); ?></a></p>
          <p id="c-button--slide-bottom" class="c-button" ><i class="las la-external-link-square-alt"></i></p>
          <p><i class="las la-bookmark"></i></p>
          <p title="Message" class="cd-btns"><i class="las la-comment"></i></p>
           <?php if(!Auth::guest()): ?>
          <?php if(Auth::user()->id == $cookbook->user_id): ?>

            <p title="Delete" data-toggle="modal" data-target=".bd-example-modal-sm"><i class="las la-trash"></i></p>            
          <?php endif; ?>
        <?php endif; ?>
          <p title="view all"><a href="/user/cookbooks/<?php echo e($cookbook->id); ?>" style="color: #fff"><i class="las la-expand"></i></a></p>
        </div>        

        <!-- COIDEA:demo:slider:for START -->
        <div class="slider slider-for">
         <?php if(count($posts) > 0): ?>
            <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="item" style="background-image: url(/storage/cover_images/<?php echo e($post->cover_image); ?>)"></div>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php endif; ?>
        </div>
        <!-- COIDEA:demo:slider:for END -->
        
        <!-- COIDEA:demo:slider:nav START -->
        <div class="slider slider-nav">
          <?php if(count($posts) > 0): ?>
            <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <div class="nav-item">
                <div class="content" style="background-image: url(/storage/cover_images/<?php echo e($post->cover_image); ?>)">
          
                  <div class="number"><?php echo e($cookbook->user->name); ?></div>
                  <div class="body">
                    <div class="location">Mong Kok, Hong Kong</div>
                    <div class="headline"><?php echo e($post->title); ?></div>
                    <a href="/r/<?php echo e($post->id); ?>" target="_blank">
                      <div class="link">Make This Dish</div>
                    </a>
                  </div>
          
                </div>
              </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          <?php endif; ?>
        </div>
        <!-- COIDEA:demo:slider:nav END -->
        <?php if(count($posts) > 0): ?>
        <!-- COIDEA:demo:navigation START -->
        <div class="navigation">
          <button class="forward"> &gt; </button>
          <button class="back"> &lt; </button>
        </div>
        <!-- COIDEA:demo:navigation END -->
        <?php endif; ?>
      </div>    
      <!-- COIDEA:demo END -->

      <!-- search -->
      <?php echo $__env->make('inc.search', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
      <!-- /search -->
    </main>

    <?php echo $__env->make('inc.profile', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <?php echo $__env->make('inc.notification', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
      
    <nav id="c-menu--slide-bottom" class="c-menu c-menu--slide-bottom">
      <button class="c-menu__close"><i class="las la-arrow-down" style="color: #fff"></i></button>
      <div class="social-media">
        <span><a href="#" target="_blank"><i class="lab la-facebook-f" style="color:#3b5998"></i></a></span>
        <span><a href="#" target="_blank" data-size="large"><i class="lab la-twitter" style="color:#00aced"></i></a></span>
        <span><a href="#" target="_blank"><i class="lab la-instagram" style="color:#517fa4"></i></a></span>
        <span><a href="#" target="_blank"><i class="lab la-pinterest-p" style="color:#cb2027"></a></i></span>
      </div>
    </nav><!-- /c-menu slide-bottom -->

    <div class="cd-panels from-right">
      <header class="cd-panel-header">
        <a href="#0" class="cd-panel-closes">Close</a>
      </header>

      <div class="cd-panel-container">
        <div class="cd-panel-content">
          
        </div> <!-- cd-panel-content -->
      </div> <!-- cd-panel-container -->
    </div> <!-- cd-panel -->


    <div id="c-mask" class="c-mask"></div><!-- /c-mask -->

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.cookbook', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\user\Documents\reparie\resources\views/cookbook/cookbook.blade.php ENDPATH**/ ?>