

<?php $__env->startSection('content'); ?>

    <main role="main" id="o-wrapper"  class="o-wrapper main-wrap">
      <div class="bottom_nav">
        <?php echo $__env->make('inc.nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
      </div>
      
      <?php echo $__env->make('inc.createrecipe', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
      <?php echo $__env->make('inc.modal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

      <div class="social">
        <p><a href="/p/<?php echo e($post->user->id); ?>" style="color:#fff; text-decoration: none;"><?php echo e($post->user->name); ?></a></p>                  
        <p title="Share" id="c-button--slide-bottom" class="c-button"><i class="las la-external-link-square-alt"></i></p>
        <?php if(!Auth::guest()): ?>
          <?php if(Auth::user()->id != $post->user_id): ?>
            <p title="Made this?"><i class="las la-utensils trying"></i></p>
            <p title="Like"><i class="las la-thumbs-up"></i></p>
          <?php endif; ?>
        <?php endif; ?>
        <p title="Comment" class="cd-btns"><i class="las la-comment"></i></p>
        <?php if(!Auth::guest()): ?>
          <?php if(Auth::user()->id == $post->user_id): ?>

            <p title="Edit"><a href="/r/<?php echo e($post->id); ?>/edit" style="color:#fff"><i class="las la-edit"></i></a></p>
            <p title="Delete" data-toggle="modal" data-target=".bd-example-modal-sm"><i class="las la-trash"></i></p>            
          <?php endif; ?>
        <?php endif; ?>
        
      </div>   

      <div class="details">
        <p><i class="las la-utensils"></i> 4.5</p>
        <p>Serves: <?php echo e($post->serves); ?></p>
        <p>Prep: <?php echo e($post->time); ?></p>
        <p>Cook: <?php echo e($post->cook); ?></p>
      </div>  

      <?php if($post->cookbook_id): ?>
        <span class="playlist"><a href="/cookbook/<?php echo e($post->cookbook_id); ?>">COOKBOOK</a></span>
      <?php endif; ?> 

      <section class="slider-pages">
        <article class="js-scrolling__page js-scrolling__page-1 js-scrolling--active">
          <div class="slider-page slider-page--left">
            <div class="slider-page--skew">
              <div class="slider-page__content" style="background-image: url(/storage/cover_images/<?php echo e($post->cover_image); ?>)">
              </div>
              <!-- /.slider-page__content -->
            </div>
            <!-- /.slider-page--skew -->
          </div>
          <!-- /.slider-page slider-page--left -->

          <div class="slider-page slider-page--right">
            <div class="slider-page--skew">
              <div class="slider-page__content">
                <h1 class="slider-page__title slider-page__title--big">
                  <?php echo e($post->title); ?>


                </h1>
                <!-- /.slider-page__title slider-page__title--big -->
                <h2 class="slider-page__title">
                  <?php echo $post->body; ?><br /> <br /> 
                  Published <?php echo e($post->updated_at->diffForHumans()); ?>             
                </h2>
                <!-- /.slider-page__title -->
                <p class="slider-page__description">
                  Please scroll down or press the down arrow on your keyboard
                </p>
                <!-- /.slider-page__description -->
              </div>
              <!-- /.slider-page__content -->
            </div>
            <!-- /.slider-page--skew -->
          </div>
          <!-- /.slider-page slider-page--right -->
        </article>
        <!-- /.js-scrolling__page js-scrolling__page-1 js-scrolling--active -->
        <article class="js-scrolling__page js-scrolling__page-2">
          <div class="slider-page slider-page--left">
            <div class="slider-page--skew">
              <div class="slider-page__content">
                <h1 class="slider-page__title" style="font-size: 4em;text-decoration: line-through;">
                  Ingredients
                </h1>
                <!-- /.slider-page__title -->
                <p class="slider-page__description">
                  <?php echo $post->ingredients; ?>

                </p>
                <!-- /.slider-page__description -->
              </div>
              <!-- /.slider-page__content -->
            </div>
            <!-- /.slider-page--skew -->
          </div>
          <!-- /.slider-page slider-page--left -->

          <div class="slider-page slider-page--right">
            <div class="slider-page--skew">
              <div class="slider-page__content"  style="background-image: url(/storage/img/ingredients.jpg)">
              </div>
              <!-- /.slider-page__content -->
            </div>
            <!-- /.slider-page--skew -->
          </div>
          <!-- /.slider-page slider-page--right -->
        </article>
        <!-- /.js-scrolling__page js-scrolling__page-2 -->
        <article class="js-scrolling__page js-scrolling__page-3">
          <div class="slider-page slider-page--left">
            <div class="slider-page--skew">
              <div class="slider-page__content" style="background-image: url(/storage/img/method.jpg)">
              </div>
              <!-- /.slider-page__content -->
            </div>
            <!-- /.slider-page--skew -->
          </div>
          <!-- /.slider-page slider-page--left -->

          <div class="slider-page slider-page--right">
            <div class="slider-page--skew">
              <div class="slider-page__content">
                <h1 class="slider-page__title" style="font-size: 4em;text-decoration: line-through;">
                  Directions
                </h1>
                <!-- /.slider-page__title -->
                <p class="slider-page__description">
                  <?php echo $post->method; ?>

                  <!--<?php echo Str::words($post->method, 100, '<br><br><a href="#" style="color: #fff; text-decoration: none;" data-toggle="modal" data-target="#exampleModalLong">Read more</a>'); ?>

                  }-->
                </p>
                <!-- /.slider-page__description -->
              </div>
              <!-- /.slider-page__content -->
            </div>
            <!-- /.slider-page--skew -->
          </div>
          <!-- /.slider-page slider-page--right -->
        </article>
        <!-- /.js-scrolling__page js-scrolling__page-3 -->
      </section>
      <!-- /.slider-pages -->  

      <!-- search -->
      <?php echo $__env->make('inc.search', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
      <!-- /search -->
    </main>

    <?php echo $__env->make('inc.profile', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    
    <?php echo $__env->make('inc.notification', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <!-- <nav id="c-menu--push-right" class="c-menu c-menu--push-right">
        <button class="c-menu__close"><i class="las la-angle-right"></i></button>
        <span class="in-popular">Popular</span> 
    </nav>/c-menu slide-top -->

    <nav id="c-menu--slide-bottom" class="c-menu c-menu--slide-bottom">
      <button class="c-menu__close"><i class="las la-arrow-down" style="color: #fff"></i></button>
      <div class="social-media">
        <span><a href="https://www.facebook.com/sharer/sharer.php?u=<?php echo e($url); ?>" target="_blank"><i class="lab la-facebook-f" style="color:#3b5998"></i></a></span>
        <span><a href="http://twitter.com/share?text=<?php echo e($post->title); ?>%20via%20@tandish&url=<?php echo e($url); ?>&hashtags=recipe,food,tandish" target="_blank" data-size="large"><i class="lab la-twitter" style="color:#00aced"></i></a></span>
        <span><a href="https://reddit.com/submit?url=<?php echo e($url); ?>&title=<?php echo e($post->title); ?>" target="_blank"><i class="lab la-reddit" style="color:#FF5700"></i></a></span>
        <span><a href="https://pinterest.com/pin/create/bookmarklet?media=http://localhost:8000/storage/cover_images/<?php echo e($post->cover_image); ?>&url=<?php echo e($url); ?>&description=<?php echo e($post->title); ?>" target="_blank"><i class="lab la-pinterest-p" style="color:#cb2027"></a></i></span>
      </div>
    </nav><!-- /c-menu slide-bottom -->

    <div class="cd-panels from-right">
      <header class="cd-panel-header">
        <a href="#0" class="cd-panel-closes">Close</a>
      </header>

      <div class="cd-panel-container">
        <div class="cd-panel-content">
          
        </div> <!-- cd-panel-content -->
      </div> <!-- cd-panel-container -->
    </div> <!-- cd-panel -->

    <div id="c-mask" class="c-mask"></div><!-- /c-mask -->

    

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.recipe', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\user\Documents\reparie\resources\views/recipe/recipe.blade.php ENDPATH**/ ?>