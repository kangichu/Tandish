<!-- Modal -->
<div class="modal fade" id="cookbook" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-sm" role="document">
    <?php echo Form::open(['action' => 'CookbooksController@store', 'method' => 'POST', 'enctype' => 'multipart/form-data', 'autocomplete' => 'off']); ?>

    <div class="modal-content" style="padding: 1.5em">
      <div class="modal-header" >
        <h5 class="modal-title" id="exampleModalLabel" style="color: #1b1931;">Create a new Cookbook, a collection of related recipes.</h5><br>
      </div>
      <div class="modal-body">
        <div class="form-group">
            <?php echo e(Form::text('title', '', ['class' => 'form-control clean-slide', 'placeholder' => 'Title'])); ?>

            <?php if($errors->has('title')): ?>
                <span class="text-danger">This field is required!</span>
            <?php endif; ?>
        </div><br>
        <div class="form-group">
            <?php echo e(Form::textarea('description', '', ['class' => 'form-control clean-slide', 'placeholder' => 'Description'])); ?>

            <?php if($errors->has('body')): ?>
                <span class="text-danger">This field is required!</span>
            <?php endif; ?>
        </div>
      </div>
      <div class="modal-footer" >
        <button type="button" class="btns btn-secondary" data-dismiss="modal" style="padding-right: 1em">Close</button>
        <button type="submit" class="btns btn-primary">Save</button>
      </div>
    </div>
    <?php echo Form::close(); ?>

  </div>
</div><?php /**PATH C:\Users\user\Documents\reparie\resources\views/inc/cookbook.blade.php ENDPATH**/ ?>