

<?php $__env->startSection('content'); ?>

    <main role="main" id="o-wrapper"  class="o-wrapper main-wrap">
      <div class="bottom_nav">
          <?php echo $__env->make('inc.nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
      </div>

      <?php echo $__env->make('inc.createrecipe', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

      <!-- Slider -->
      <section class="velo-slides" data-velo-slider="on" data-velo-theme="light">
          <!-- Slide -->

          <?php if(count($posts) > 0): ?>

            <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

              <section class="velo-slide">
                <!-- Pretitle Hint -->
                <span class="velo-slider__hint"><span><span>Check Them Recipes</span></span></span> <!-- Slide BG -->
                <div class="velo-slide__bg">
                  <!-- Borders -->
                  <span class="border"><span></span></span> <!-- Img -->
                  <figure class="velo-slide__figure" style="background-image: url(/storage/cover_images/<?php echo e($post->cover_image); ?>)"></figure>
                </div>

                <!-- Header -->
                <header class="velo-slide__header">
                  <h3 class="velo-slide__title">
                    <span class="oh">
                      <span  style="cursor:pointer; margin-bottom:.3em; font-size: .5em !important;"><a href="/p/<?php echo e($post->user->id); ?>" style="color: #fff">
                        <?php if(!Auth::guest()): ?>
                          <?php if(Auth::user()->id == $post->user->id): ?>
                           My Post
                          <?php else: ?>
                           <?php echo e($post->user->name); ?>

                          <?php endif; ?>
                        <?php endif; ?>
                       
                      </a>
                      </span><br />
                      <span><?php echo $post->title; ?></span>
                    </span>
                  </h3>
                  <p class="velo-slide__text">
                    <span class="oh">
                      <span>
                        <?php echo e($post->body); ?><br />
                        <small style="letter-spacing: 0 !important">Published <?php echo e($post->updated_at->diffForHumans()); ?></small><br />
                        <?php if($post->cookbook_id): ?>
                          <span class="playlist"><a href="/cookbook/<?php echo e($post->cookbook_id); ?>" style="color: #fff">COOKBOOK</a> </span><br />
                        <?php endif; ?>
                        <!-- <span class="others-two"><i class="las la-utensils"></i><i class="las la-utensils"></i><i class="las la-utensils"></i><i class="las la-utensils"></i>  28 people have tried this recipe </span> -->
                      </span>
                    </span>
                  </p>
                  <span class="velo-slide__btn">
                    <a class="btn-draw btn--white" href="/r/<?php echo e($post->id); ?>">
                      <span class="btn-draw__text"><span>Make This Dish</span></span>
                    </a>
                  </span>
                  
                </header>
              </section>

            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            <!-- Slides Nav -->
            <nav class="velo-slides-nav">
              <ul class="velo-slides-nav__list">
                <li>
                  <a class="js-velo-slides-prev velo-slides-nav__prev inactive" href="#0"><i class="icon-up-arrow"></i></a>
                </li>
                <li>
                  <a class="js-velo-slides-next velo-slides-nav__next" href="#0"><i class="icon-down-arrow"></i></a>
                </li>
              </ul>
            </nav>

          <?php else: ?>
              <p class="no_p">No Recipes Available at the Moment.</p>
          <?php endif; ?>

          
      </section>

      <!-- search -->
      <?php echo $__env->make('inc.search', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
      <!-- /search -->
    </main>

    <?php echo $__env->make('inc.profile', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <?php echo $__env->make('inc.notification', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <nav id="c-menu--push-right" class="c-menu c-menu--push-right">
      <button class="c-menu__close"><i class="las la-angle-right"></i></button>
      <!--<span class="in-popular">Popular</span> -->  
    </nav><!-- /c-menu slide-top -->

    <nav id="c-menu--slide-right" class="c-menu c-menu--slide-right">
      <button class="c-menu__close"><i class="las la-angle-right"></i></button>
    </nav><!-- /c-menu push-top -->

    <nav id="c-menu--slide-left" class="c-menu c-menu--slide-left">
      <button class="c-menu__close"><i class="las la-angle-left"></i></button>
    </nav><!-- /c-menu slide-left -->

    <nav id="c-menu--push-left" class="c-menu c-menu--push-left">
      <span class="c-menu__close"><i class="las la-angle-left"></i></span>
      <h1 class="profUser"><?php echo e(Auth::user()->name); ?></h1>
    </nav><!-- /c-menu push-left -->

    <div id="c-mask" class="c-mask"></div><!-- /c-mask -->

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\user\Documents\reparie\resources\views/home/index.blade.php ENDPATH**/ ?>