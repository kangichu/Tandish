<main data-hijacking="off" data-animation="scaleDown" class="mains">
  <section class="cd-section visible">
    <div>
      <h2>Page Scroll Effects</h2>
    </div>
  </section>

  <section class="cd-section">
    <div>
      <h2>Section 2</h2>
    </div>
  </section>

  <section class="cd-section">
    <div>
      <h2>Section 3</h2>
    </div>
  </section>

  <section class="cd-section">
    <div>
      <h2>Section 4</h2>
    </div>
  </section>

  <section class="cd-section">
    <div>
      <h2>Section 5</h2>
    </div>
  </section>

  <nav>
    <ul class="cd-vertical-nav">
      <li><a href="#0" class="cd-prev inactive">Next</a></li>
      <li><a href="#0" class="cd-next">Prev</a></li>
    </ul>
  </nav> <!-- .cd-vertical-nav -->
</main><?php /**PATH C:\Users\user\Documents\reparie\resources\views/inc/recipes.blade.php ENDPATH**/ ?>