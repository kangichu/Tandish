<div class="modal fade bd-example-modal-lg" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-sm">
    <?php echo Form::open(['action' => 'PostsController@store', 'method' =>'POST', 'class' => 'float-right']); ?>

    <div class="modal-content">
    	<div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Feedback</h5>
      </div>
      <div class="modal-body">
        
            <?php echo e(Form::textarea('feedback', '', ['class' => 'form-control feedback', 'placeholder' => 'Enter Feedback'])); ?>

      </div>
      <div class="modal-footer">
      	<span type="button" data-dismiss="modal" style="cursor: pointer;">Close</span>
        <?php echo e(Form::submit('Submit', ['class' => 'btn submit'])); ?>

    	</div>
    </div>
    <?php echo Form::close(); ?>

  </div>
</div><?php /**PATH C:\Users\user\Documents\reparie\resources\views/inc/feedback.blade.php ENDPATH**/ ?>