

<?php $__env->startSection('content'); ?>
    
    <div class="container">
        <span class="velo-slider__hints"><span><span>Edit Profile</span></span></span>
        <?php echo Form::open(['action' => ['ProfilesController@update', $profile->id], 'method' => 'POST', 'enctype' => 'multipart/form-data']); ?>


             <?php echo csrf_field(); ?>

            <div class="form-group">
                <?php echo e(Form::text('bio', $profile->bio, ['class' => 'form-control', 'placeholder' => 'My Bio'])); ?>

            </div>

            <div class="form-group">
                <?php echo e(Form::text('facebook', $profile->facebook, ['class' => 'form-control', 'placeholder' => 'Facebook Account'])); ?>

            </div>
            <div class="form-group">
                <?php echo e(Form::text('twitter', $profile->twitter, ['class' => 'form-control', 'placeholder' => 'Twitter Account'])); ?>

            </div>

            <div class="form-group">
                <?php echo e(Form::text('instagram', $profile->instagram, ['class' => 'form-control', 'placeholder' => 'Instagram Account'])); ?>

            </div>
            <div class="form-group">
                <?php echo e(Form::text('pinterest', $profile->pinterest, ['class' => 'form-control', 'placeholder' => 'Pinterest Account'])); ?>

            </div>

            <div class="form-group">
                <?php echo e(Form::text('youtube', $profile->youtube, ['class' => 'form-control', 'placeholder' => 'Youtube Channel'])); ?>

            </div>
            <div class="form-group">
                <?php echo e(Form::text('link', $profile->link, ['class' => 'form-control', 'placeholder' => 'Your Website'])); ?>

            </div>
            
                

            <?php echo e(Form::hidden('_method', 'PUT')); ?>

            <?php echo e(Form::submit('Submit', ['class'=>'btn btn-primary'])); ?>

        <?php echo Form::close(); ?>

    </div>
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\user\Documents\reparie\resources\views/profile/edit.blade.php ENDPATH**/ ?>