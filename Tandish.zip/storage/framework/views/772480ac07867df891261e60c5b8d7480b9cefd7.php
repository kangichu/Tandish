


	<?php $__env->startSection('content'); ?>
	<main role="main" id="o-wrapper"  class="o-wrapper main-wrap">
		<div class="bottom_nav">
            <?php echo $__env->make('inc.nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>

        <?php echo $__env->make('inc.createrecipe', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php echo $__env->make('inc.feedback', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <?php if(count($posts) > 0): ?>

			<section class="intro-section">
			  <h1 class="intro-heading">Search Results</h1>

			  <p>Here are the results that closely match what you wanted. <br><br><?php echo e($postCount); ?> results</p>
			</section>

			<?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=> $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<!-- Photos via Unsplash Source https://source.unsplash.com/ -->
				<section class="content-section" data-scroll>
				  <figure class="figure"><img src="/storage/cover_images/<?php echo e($post->cover_image); ?>" /></figure>
				  <div class="content">
				    <header class="header">
				      <div class="subheading"><a href="/p/<?php echo e($post->user->id); ?>" style="color: #fff; text-decoration: none;"><?php echo e($post->user->name); ?></a></div>
				      <h2 class="heading"><?php echo $post->title; ?></h2>
				    </header>
				    <p class="paragraph">
				     	<?php echo e($post->body); ?><br>
		              	<small style="letter-spacing: 0 !important">Published <?php echo e($post->created_at->diffForHumans()); ?></small><br /><br />
		              	 <span class="playlist"><a href="/cookbook" style="color: #fff">COOKBOOK</a> 
		              	 </span><br />
		              	<span class="others-two"><i class="las la-utensils"></i><i class="las la-utensils"></i><i class="las la-utensils"></i><i class="las la-utensils"></i>  28 people have tried this recipe </span><br><br>
				      	<a href="/r/<?php echo e($post->id); ?>" class="link_btn">Make This Dish</a>
				    </p>
				  </div>
				</section>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

		<?php else: ?>
            <section class="intro-section">
			  <h1 class="intro-heading">Search Results</h1>

			  <p>There were no recipes with that search term. Please try something else. <br><br><?php echo e($postCount); ?> results</p>
			</section>
        <?php endif; ?>

		<!-- search -->
        <?php echo $__env->make('inc.search', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <!-- /search -->
	</main>

    <?php echo $__env->make('inc.profile', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <?php echo $__env->make('inc.notification', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <nav id="c-menu--push-right" class="c-menu c-menu--push-right">
      <button class="c-menu__close"><i class="las la-angle-right"></i></button>
      <!--<span class="in-popular">Popular</span> -->  
    </nav><!-- /c-menu slide-top -->

    <nav id="c-menu--slide-right" class="c-menu c-menu--slide-right">
      <button class="c-menu__close"><i class="las la-angle-right"></i></button>
    </nav><!-- /c-menu push-top -->

    <nav id="c-menu--slide-left" class="c-menu c-menu--slide-left">
      <button class="c-menu__close"><i class="las la-angle-left"></i></button>
    </nav><!-- /c-menu slide-left -->

    <nav id="c-menu--push-left" class="c-menu c-menu--push-left">
      <span class="c-menu__close"><i class="las la-angle-left"></i></span>
      <h1 class="profUser"><?php echo e(Auth::user()->name); ?></h1>
    </nav><!-- /c-menu push-left -->

    <div id="c-mask" class="c-mask"></div><!-- /c-mask -->
	    

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.search', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\user\Documents\reparie\resources\views/search/search.blade.php ENDPATH**/ ?>