

<?php $__env->startSection('content'); ?>

    <main role="main" id="o-wrapper"  class="o-wrapper main-wrap">

     <!-- Navigation -->
      <div class="menu_nav">
        <div id="c-button--push-left" class="c-button profile"><img src="img/profile1.jpg" alt="profile1"></div>
        <div class="filter">
          <button class="btn btn--filter"><i class="las la-home"></i></button>
        </div>
        <div class="notification">
          <button title="notification" class="btn btn--notification c-button"><i class="las la-bell"></i></button>
        </div>
        <div class="popular">
          <button title="popular"  id="c-button--push-right" class="btn btn--popular c-button"><i class="las la-fire-alt"></i></button>
        </div>
        <div class="search-wrap">
          <button title="search" id="btn-search" class="btn btn--popular"><i class="las la-search"></i></button>
        </div> 
        <div class="logout">
          <button title="logout" class="btn btn--notification">
            <a href="<?php echo e(route('logout')); ?>"
               onclick="event.preventDefault();
                             document.getElementById('logout-form').submit();">
                <i class="las la-sign-out-alt"></i>
            </a>

            <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                <?php echo csrf_field(); ?>
            </form>
          </button>
        </div>      
      </div>

      <div class="chat">
        <button id="c-button--push-left" class="btn btn--chat c-button"><i class="las la-comment"></i></button>
      </div>

      <div class="basic-info">
        <span>Recipes: <p>23</p></span>
        <span>Views: <p>300</p></span>
      </div>
      
      <!-- /Navigation -->

      <!-- COIDEA:demo START -->
      <div class="carousel">

        <header class="velo-slide__header">
          <h3 class="velo-slide__title">
            <span class="oh">
              <span class="username">
                James Brown
              </span>
              <br />
              <span style="width: 16em">My name is Ozymandias, king of kings: Look on my works, ye Mighty, and despair!</span>
            </span>
          </h3>
          <p class="velo-slide__text">
            <span class="oh">
              <span>
                I'm a Creative Developer currently building web things at the Seattle Branding + Interactive firm, Urban Influence.<br />
              </span>
            </span>
          </p>
          
        </header>

        <span class="velo-slider__hint"><span><span>Recipelist</span></span></span>

        <div class="social">
          <!--<p><small>chef</small> Park Lee  </p>-->
          <p><i class="las la-external-link-square-alt"></i></p>
          <p id="c-button--slide-right" class="c-button"><i class="las la-bookmark"></i></p>
          <p><i class="las la-thumbs-up"></i></p>
          <p><i class="las la-thumbs-down"></i></p>
          <p title="view all" id="c-button--slide-top" class="c-button"><i class="las la-expand"></i></p>
        </div>        

        <!-- COIDEA:demo:slider:for START -->
        <div class="slider slider-for">
          <div class="item" style="background-image: url(img/appetizer-brunch-close-up-1095550.jpg)"></div>
          <div class="item" style="background-image: url(img/blur-breakfast-close-up-376464.jpg)"></div>
          <div class="item" style="background-image: url(img/burger-chips-dinner-70497.jpg)"></div>
          <div class="item" style="background-image: url(img/carrots-cucumber-delicious-1640777.jpg)"></div>
          <div class="item" style="background-image: url(img/close-up-cooking-dinner-46239.jpg)"></div>
        </div>
        <!-- COIDEA:demo:slider:for END -->
        
        <!-- COIDEA:demo:slider:nav START -->
        <div class="slider slider-nav">
          <div class="nav-item">
            <div class="content" style="background-image: url(img/appetizer-brunch-close-up-1095550.jpg)">
      
              <div class="number">01</div>
              <div class="body">
                <div class="location">Mong Kok, Hong Kong</div>
                <div class="headline">Photo by<br>Ryan Tang</div>
                <a href="#0">
                  <div class="link">Make This Dish</div>
                </a>
              </div>
      
            </div>
          </div>
          <div class="nav-item">
            <div class="content" style="background-image: url(img/blur-breakfast-close-up-376464.jpg)">
      
              <div class="number">02</div>
              <div class="body">
                <div class="location">Shibuya, Japan</div>
                <div class="headline">Photo by<br>Benjamin Hung</div>
                <a href="#0">
                  <div class="link">Make This Dish</div>
                </a>
              </div>
      
            </div>
          </div>
          <div class="nav-item">
            <div class="content" style="background-image: url(img/burger-chips-dinner-70497.jpg)">
      
              <div class="number">03</div>
              <div class="body">
                <div class="location">New York, United States</div>
                <div class="headline">Photo by<br>Matteo Modica</div>
                <a href="#0">
                  <div class="link">Make This Dish</div>
                </a>
              </div>
      
            </div>
          </div>
          <div class="nav-item">
            <div class="content" style="background-image: url(img/carrots-cucumber-delicious-1640777.jpg)">
      
              <div class="number">04</div>
              <div class="body">
                <div class="location">Tokyo, Japan</div>
                <div class="headline">Photo by<br>Steven Roe</div>
                <a href="#0">
                  <div class="link">Make This Dish</div>
                </a>
              </div>
      
            </div>
          </div>
          <div class="nav-item">
            <div class="content" style="background-image: url(img/close-up-cooking-dinner-46239.jpg)">
      
              <div class="number">05</div>
              <div class="body">
                <div class="location">Yau Ma Tei, Hong Kong</div>
                <div class="headline">Photo by<br>Sean Foley</div>
                <a href="#0">
                  <div class="link">Make This Dish</div>
                </a>
              </div>
      
            </div>
          </div>
        </div>
        <!-- COIDEA:demo:slider:nav END -->
        
        <!-- COIDEA:demo:navigation START -->
        <div class="navigation">
          <button class="forward"> &gt; </button>
          <button class="back"> &lt; </button>
        </div>
        <!-- COIDEA:demo:navigation END -->
      
      </div>    
      <!-- COIDEA:demo END -->

      <!-- search -->
      <div class="search">
        <button id="btn-search-close" class="btn btn--search-close" aria-label="Close search form"><svg class="icon icon--cross"><use xlink:href="#icon-cross"></use></svg></button>
        <form class="search__form" action="">
          <input class="search__input" name="search" type="search" placeholder="recipe" autocomplete="off" autocorrect="off" autocapitalize="off" spellcheck="false" />
          <span class="search__info">Hit enter to search or ESC to close</span>
        </form>
        <div class="search__related">
          <div class="search__suggestion">
            <h3>May We Suggest?</h3>
            <p>#drone #funny #catgif #broken #lost #hilarious #good #red #blue #nono #why #yes #yesyes #aliens #green</p>
          </div>
          <div class="search__suggestion">
            <h3>Is It This?</h3>
            <p>#good #red #hilarious #blue #nono #why #yes #yesyes #aliens #green #drone #funny #catgif #broken #lost</p>
          </div>
          <div class="search__suggestion">
            <h3>Needle, Where Art Thou?</h3>
            <p>#broken #lost #good #red #funny #hilarious #catgif #blue #nono #why #yes #yesyes #aliens #green #drone</p>
          </div>
        </div>
      </div>
      <!-- /search -->
    </main>

    <nav class="cd-nav-container" id="cd-nav">
      <header>
        <a href="#0" class="cd-close-nav">Close</a>
      </header>
  
      <ul class="cd-nav">
      
      </ul> <!-- .cd-3d-nav -->
    </nav>
  
    <div class="cd-overlay"><!-- shadow layer visible when navigation is visible --></div>
      
    <nav id="c-menu--push-left" class="c-menu c-menu--push-left">
      <button class="c-menu__close">&larr;</button>
      
    </nav><!-- /c-menu push-left -->

    <nav id="c-menu--push-right" class="c-menu c-menu--push-right">
      <button class="c-menu__close">&rarr;</button>
    </nav><!-- /c-menu push-right -->

    <nav id="c-menu--slide-right" class="c-menu c-menu--slide-right">
      <button class="c-menu__close">&rarr;</button>
      <button class="create-board"><i class="las la-plus"></i> Create Board</button>
    </nav><!-- /c-menu slide-right -->

    <nav id="c-menu--slide-top" class="c-menu c-menu--slide-top">
      <button class="c-menu__close"><strong>x</strong></button>
      
    </nav><!-- /c-menu slide-bottom -->

    <nav id="c-menu--push-left" class="c-menu c-menu--push-left">
      <button class="c-menu__close">&larr;</button>
    </nav><!-- /c-menu push-left -->

    <div id="c-mask" class="c-mask"></div><!-- /c-mask -->

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.playlist', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\user\Documents\reparie\resources\views/playlist/playlist.blade.php ENDPATH**/ ?>