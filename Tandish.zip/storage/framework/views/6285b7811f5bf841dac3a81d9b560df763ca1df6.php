<div class="menu-wrap">
  <nav class="menu-content">
    <div class="icon-list">
      <a href="#" id="close-button" title="close"><i class="las la-times"></i></a>
      <a href="/p/<?php echo e(Auth::user()->id); ?>"><i class="las la-user-circle"></i></a>
      <a href="/settings"><i class="las la-cog"></i></a>
      <a href="/about-us"><i class="las la-question"></i></a>
      <a href="<?php echo e(route('logout')); ?>" 
         onclick="event.preventDefault(); document.getElementById('logout-form').submit();">
        <i class="las la-door-open"></i>
      </a>
      <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
          <?php echo csrf_field(); ?>
      </form>
    </div>
  </nav>
</div><?php /**PATH C:\Users\user\Documents\reparie\resources\views/inc/profile.blade.php ENDPATH**/ ?>