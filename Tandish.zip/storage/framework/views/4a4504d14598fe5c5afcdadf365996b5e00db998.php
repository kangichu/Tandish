

<?php $__env->startSection('content'); ?>

    <main id="o-wrapper" class="o-wrapper container">
      <div class="menu_nav">
        <?php echo $__env->make('inc.nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
      </div>

      <?php echo $__env->make('inc.createrecipe', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

      <canvas id="bubble"></canvas>

      <div class="social-media">
        <div class="tools">
          <?php if(!Auth::guest()): ?>
            <?php if(Auth::user()->id != $user->id): ?>
               <span title="Follow" class="btn btn-sub"><i class="las la-check"></i></span>
            <?php endif; ?>
          <?php endif; ?>
          <span title="Bookmarks" id="c-button--slide-left" class="c-button"><i class="las la-bookmark"></i></span>
          <span title="Cookbooks" id="c-button--slide-right" class="c-button"><i class="las la-book-open"></i></span>
          <?php if(!Auth::guest()): ?>
            <?php if(Auth::user()->id != $user->id): ?>
               <span title="Message" class="cd-btns"><i class="las la-comment"></i></span>
            <?php else: ?>
              <span title="My Messages" class="cd-btns"><i class="las la-comment"></i></span>
            <?php endif; ?>
          <?php endif; ?>
          
          <?php if(!Auth::guest()): ?>
            <?php if(Auth::user()->id != $user->id): ?>
               <span title="<?php echo e($user->name); ?>'s Recipes"><a href="/user/posts/<?php echo e($user->id); ?>"><i class="las la-expand"></i></a></span>
            <?php else: ?>
              <span title="My Recipes"><a href="/user/posts/<?php echo e($user->id); ?>"><i class="las la-expand"></i></a></span>
            <?php endif; ?>
          <?php endif; ?>


          
        </div>
      </div>
      <?php if(count($posts) > 0): ?>
          <span class="velo-slider__hints"><span><span>Check Them Recipes</span></span></span>
        <?php else: ?>
          <span class="velo-slider__hints"><span><span>Create your own Recipes</span></span></span>
       <?php endif; ?>
      <div class="bas_info">
        <div style="font-size: .8em"><?php echo e($user->name); ?></div>
        <div class="recipes" title="Recipes">
          <span>RECIPES</span>
          <span style="padding-left: .3em;"><?php echo e($postCount); ?></span>
        </div>
        <div class="subs" title="Cookbooks">
          <span><a href="/cookbook">COOKBOOKS</a></span>
          <span style="padding-left: .3em"><?php echo e($cookbookCount); ?></span>
        </div>
        <div class="bookmarks" title="Bookmarks">
          <span>BOOKMARKS</span>
          <span style="padding-left: .3em">0</span>
        </div>  
      </div> 
        
      <div id="hero-slides">
        <div id="header">
          <div id="logo"></div>
          <div id="menu">
            <i class="las la-play"></i>
          </div>
        </div>
        <div id="slides-cont">
          <?php if(count($posts) >= 4): ?>
          <div class="button" id="next"></div>
          <div class="button" id="prev"></div>
          <?php endif; ?>
          <div id="slides">
            <?php if(count($posts) >= 4): ?>
              <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="slide" style="background-image: url(/storage/cover_images/<?php echo e($post->cover_image); ?>);">
                  <div class="number"><?php echo e($post->updated_at->diffForHumans()); ?></div>
                  <div class="body">
                    <div class="location">Shibuya, Japan</div>
                    <div class="headline"><?php echo e($post->title); ?></div><a href="/r/<?php echo e($post->id); ?>">
                      <div class="link">Make This Dish</div></a>
                  </div>
                </div>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>
          </div>
          <div id="next-catch"></div>
          <div id="prev-catch"></div>
        </div>
        <!--<div id="footer"><a href="https://dribbble.com/shots/3888265-Motion-Study" target="_blank">
          <div id="dribbble"></div></a>
        </div>-->
      </div>

      <!-- search -->
      <?php echo $__env->make('inc.search', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
      <!-- /search -->
    </main>

    <?php echo $__env->make('inc.profile', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('inc.cookbook', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('inc.notification', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <nav id="c-menu--slide-right" class="c-menu c-menu--slide-right">
      <button class="c-menu__close"><!-- <i class="las la-angle-right"></i> --></button>
      <br><br>
      

      <?php if(count($cookbooks) > 0): ?>
        <?php $__currentLoopData = $cookbooks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cookbook): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <div class="blog-slider">
            <div class="blog-slider__wrp swiper-wrapper">
              <div class="blog-slider__item swiper-slide">
                <div class="blog-slider__content">
                  <span class="blog-slider__code"><?php echo e($cookbook->created_at->diffForHumans()); ?></span>
                  <div class="blog-slider__title"><?php echo e($cookbook->title); ?></div>
                  <div class="blog-slider__text"><?php echo e($cookbook->description); ?></div>
                  <a href="/cookbook/<?php echo e($cookbook->id); ?>" class="blog-slider__button">View Cookbook</a>                    
                </div>
              </div>
            </div>
          </div><br><br>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      <?php endif; ?>

      <?php if(!Auth::guest()): ?>
        <?php if(Auth::user()->id === $user->id): ?>
          <button class="create-boards" data-toggle="modal" data-target="#cookbook"><i class="las la-plus"></i></button>
        <?php endif; ?>
      <?php endif; ?> 
        
    </nav><!-- /c-menu push-top -->

    <nav id="c-menu--slide-left" class="c-menu c-menu--slide-left">
        <button class="c-menu__close"><i class="las la-angle-left"></i></button>
    </nav><!-- /c-menu slide-left -->

    <nav id="c-menu--push-right" class="c-menu c-menu--push-right">
        <button class="c-menu__close"><i class="las la-angle-right"></i></button>
    </nav><!-- /c-menu push-right -->

    <div class="cd-panels from-right">
      <header class="cd-panel-header">
        <a href="#0" class="cd-panel-closes">Close</a>
      </header>

      <div class="cd-panel-container">
        <div class="cd-panel-content">
          
        </div> <!-- cd-panel-content -->
      </div> <!-- cd-panel-container -->
    </div> <!-- cd-panel -->

    <div id="c-mask" class="c-mask"></div><!-- /c-mask -->

<?php $__env->stopSection(); ?>
  
<?php echo $__env->make('layouts.profile', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\user\Documents\reparie\resources\views/profile/profile.blade.php ENDPATH**/ ?>