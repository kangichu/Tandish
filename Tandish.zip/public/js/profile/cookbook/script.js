var swiper = new Swiper('.blog-slider', {
      spaceBetween: 30,
      effect: 'fade',
    });